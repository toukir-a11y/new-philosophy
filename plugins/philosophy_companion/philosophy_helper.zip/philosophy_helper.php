<?php

/*
plugin Name: philosophy_helper
plugin URI: 
Author: team wppool
plugin URI:
Description: this plugin about philosophy 
Version: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: philosophy_companion

*/

function cptui_register_my_cpts_book() {

	/**
	 * Post Type: My Books.
	 */

	$labels = [
		"name" => __( "My Books", "phylosophy" ),
		"singular_name" => __( "Book", "phylosophy" ),
		"menu_name" => __( "My Books", "phylosophy" ),
		"all_items" => __( "All Books", "phylosophy" ),
		"add_new" => __( "Add new book", "phylosophy" ),
	];

	$args = [
		"label" => __( "My Books", "phylosophy" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "book", "with_front" => true ],
		"query_var" => true,
		"supports" => [ "title", "editor", "thumbnail" ],
		"show_in_graphql" => false,
	];

	register_post_type( "book", $args );
}

add_action( 'init', 'cptui_register_my_cpts_book' );



?>